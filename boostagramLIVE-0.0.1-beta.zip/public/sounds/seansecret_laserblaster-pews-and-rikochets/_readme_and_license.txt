Sound pack downloaded from Freesound
----------------------------------------

"Laser/Blaster Pews and Rikochets"

This pack of sounds contains sounds by the following user:
 - SeanSecret ( https://freesound.org/people/SeanSecret/ )

You can find this pack online at: https://freesound.org/people/SeanSecret/packs/25017/


Pack description
----------------

We had to make a lasersound from simple soundwaves and noise. We only needed to make one - so I made 17 :)

Putting them out here so they won&#x27;t be collecting dust on my hardrive - after all, I&#x27;m quite proud of these sounds which I made in like 2 days xD


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 440668__seansecret__laser-impact.wav
    * url: https://freesound.org/s/440668/
    * license: Creative Commons 0
  * 440667__seansecret__medium-blaster.wav
    * url: https://freesound.org/s/440667/
    * license: Creative Commons 0
  * 440666__seansecret__tank-blaster.wav
    * url: https://freesound.org/s/440666/
    * license: Creative Commons 0
  * 440665__seansecret__remade-star-wars-blaster.wav
    * url: https://freesound.org/s/440665/
    * license: Creative Commons 0
  * 440664__seansecret__heavy-anti-air-blaster.wav
    * url: https://freesound.org/s/440664/
    * license: Creative Commons 0
  * 440663__seansecret__spaceship-blaster.wav
    * url: https://freesound.org/s/440663/
    * license: Creative Commons 0
  * 440662__seansecret__heavy-blaster.wav
    * url: https://freesound.org/s/440662/
    * license: Creative Commons 0
  * 440661__seansecret__classic-laser-pew.wav
    * url: https://freesound.org/s/440661/
    * license: Creative Commons 0
  * 440660__seansecret__light-blaster-weapon.wav
    * url: https://freesound.org/s/440660/
    * license: Creative Commons 0
  * 440659__seansecret__rikochet-v1-light-3.wav
    * url: https://freesound.org/s/440659/
    * license: Creative Commons 0
  * 440658__seansecret__rikochet-v2-medium-1.wav
    * url: https://freesound.org/s/440658/
    * license: Creative Commons 0
  * 440657__seansecret__rikochet-v2-medium-2.wav
    * url: https://freesound.org/s/440657/
    * license: Creative Commons 0
  * 440656__seansecret__rikochet-v2-medium-3.wav
    * url: https://freesound.org/s/440656/
    * license: Creative Commons 0
  * 440655__seansecret__heavy-spaceship-blaster.wav
    * url: https://freesound.org/s/440655/
    * license: Creative Commons 0
  * 440654__seansecret__scifi-blaster.wav
    * url: https://freesound.org/s/440654/
    * license: Creative Commons 0
  * 440653__seansecret__rikochet-v1-light-1.wav
    * url: https://freesound.org/s/440653/
    * license: Creative Commons 0
  * 440652__seansecret__rikochet-v1-light-2.wav
    * url: https://freesound.org/s/440652/
    * license: Creative Commons 0


